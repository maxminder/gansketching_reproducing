wget https://www.cs.cmu.edu/~gansketching/files/pretrained_models.zip -O ./pretrained/pretrained_models.zip
unzip ./pretrained/pretrained_models.zip -d ./pretrained
rm ./pretrained/pretrained_models.zip
