wget https://www.cs.cmu.edu/~gansketching/files/eval_data.zip -O ./data/eval_data.zip
unzip ./data/eval_data.zip -d ./data
rm ./data/eval_data.zip
