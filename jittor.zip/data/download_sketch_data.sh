wget https://www.cs.cmu.edu/~gansketching/files/sketch_data.zip -O ./data/sketch_data.zip
unzip ./data/sketch_data.zip -d ./data
rm ./data/sketch_data.zip
